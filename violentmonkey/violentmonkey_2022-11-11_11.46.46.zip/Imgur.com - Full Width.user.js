// ==UserScript==
// @name          Imgur.com - Full Width
// @namespace     http://userstyles.org
// @description	  Displays the image list in full width of the page.
// @author        eXo-Necro
// @homepage      https://userstyles.org/styles/126145
// @include       http://imgur.com/*
// @include       https://imgur.com/*
// @include       http://*.imgur.com/*
// @include       https://*.imgur.com/*
// @run-at        document-start
// @icon          https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://imgur.com&size=64
// @version       0.20160330110854
// ==/UserScript==
(function() {var css = [
	".outside {",
	"    width: calc(100% - 70px)!important;",
	"    min-width: 1000px!important;",
	"}",
	".main .panel #imagelist.home-gallery {",
	"    width: calc(100% - 390px);",
	"}"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
