// ==UserScript==
// @name         Wykop.pl - reload automatically after error page
// @namespace    https://my-userscripts.netlify.com/
// @version      0.1
// @description  Skrypt automatycznie odswieza strone wykopu po wystapieniu komunikatu "trwa aktualizacja serwisu"
// @author       @1tn00pr at wykop.pl
// @match        https://www.wykop.pl/*
// @icon https://t1.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://wykop.pl&size=64
// @grant        none
// ==/UserScript==

(function() {
    if(document.title == "Ups..."){
        window.location.reload();
    }
})();