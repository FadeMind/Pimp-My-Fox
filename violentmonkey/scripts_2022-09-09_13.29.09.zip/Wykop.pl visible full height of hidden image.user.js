// ==UserScript==
// @name          Wykop.pl visible full height of hidden image
// @namespace     http://userstyles.org
// @description	  Showing full height of hidden image without clicking on "show rest of hidden image" button.
// @author        pczstyles
// @homepage      https://userstyles.org/styles/149620
// @include       http://wykop.pl/*
// @include       https://wykop.pl/*
// @include       http://*.wykop.pl/*
// @include       https://*.wykop.pl/*
// @icon          https://t1.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://wykop.pl&size=64
// @run-at        document-start
// @version       0.20171014163314
// ==/UserScript==
(function() {var css = [
	"@namespace url(http://www.w3.org/1999/xhtml);",
	".media-content.too-long-pic { max-height: inherit; }",
	"        .media-content.too-long-pic > .expand { display: none; }"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
