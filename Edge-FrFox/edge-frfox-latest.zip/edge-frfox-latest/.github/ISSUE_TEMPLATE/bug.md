---
name: 🐛 Bug
about: Report a bug
labels: bug
---

**Description**
Include clear explaination of bug and how to reproduce.

**Include screenshot / video recording if possible.**

**Configuration**
- Firefox Version: 
- OS: (eg. Windows, macOS, etc.)
