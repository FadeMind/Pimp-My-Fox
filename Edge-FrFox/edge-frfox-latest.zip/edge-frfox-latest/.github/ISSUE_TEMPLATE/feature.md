---
name: ✨ Feature
about: Request a new feature / enhancement
labels: enhancement
---

**Description**
Include clear explaination of the feature and how it works.

**Include screenshot / video recording if possible.**
